# Reusable functions for an ITEM-BASED COLLABORATIVE FILTERING
# recommender. "Collaborative filtering" means recommendations come
# purely from the PATTERN of who bought what -- no product descriptions,
# categories, or prices are used. The core idea: two products are
# "similar" if the same customers tend to buy both; a customer gets
# recommended products similar to what they've already bought.
#
# This is deliberately different from the earlier network-analysis
# project: that project studied the co-purchase graph's STRUCTURE
# (hubs, bridges, communities) as an end in itself. This project uses
# similarity between products for a specific PRACTICAL purpose --
# generating and evaluating actual recommendations -- and adds a
# train/test evaluation step the network project didn't need.

library(dplyr)
library(Matrix)
library(tibble)

#' Build a sparse customer x product matrix from (customer_id,
#' description) pairs. Sparse storage matters here: most customers
#' bought only a tiny fraction of the full catalog, so a dense matrix
#' would waste enormous memory storing mostly zeros.
#'
#' @param customer_products A tibble with customer_id and description.
#' @return A sparse matrix (customers as rows, products as columns),
#'   with 1 = "this customer bought this product," 0 = did not.
build_interaction_matrix <- function(customer_products) {
  customers <- unique(customer_products$customer_id)
  products  <- unique(customer_products$description)

  i <- match(customer_products$customer_id, customers)
  j <- match(customer_products$description, products)

  m <- sparseMatrix(i = i, j = j, x = 1, dims = c(length(customers), length(products)))
  rownames(m) <- as.character(customers)
  colnames(m) <- products
  m
}

#' Compute item-item COSINE SIMILARITY from the interaction matrix.
#' Two products are similar if the SAME set of customers tends to buy
#' both. Cosine similarity measures the angle between two products'
#' customer-purchase vectors -- it naturally handles the fact that
#' popular products are bought by many customers (large vectors) by
#' normalizing for vector length, so a hugely popular product isn't
#' automatically "similar" to everything just because lots of people
#' bought it.
#'
#' @param interaction_matrix Output of build_interaction_matrix().
#' @return A dense product x product similarity matrix (diagonal = 1).
compute_item_similarity <- function(interaction_matrix) {
  # Cosine similarity between columns = (X'X) normalized by each
  # column's norm. Computing X'X directly on the sparse matrix is
  # far more efficient than converting to dense first.
  cross_prod <- Matrix::crossprod(interaction_matrix)   # product x product, raw co-purchase counts
  norms <- sqrt(Matrix::diag(cross_prod))
  sim <- as.matrix(cross_prod / outer(norms, norms))
  diag(sim) <- 0   # a product isn't a recommendation for itself
  sim
}

#' Recommend products for a single customer, based on what's similar
#' to what they've already bought -- NOT simply "most popular overall,"
#' which would recommend the same handful of bestsellers to everyone
#' regardless of their actual purchase history.
#'
#' @param customer_id The customer to recommend for.
#' @param interaction_matrix The customer x product matrix.
#' @param item_similarity The product x product similarity matrix.
#' @param n Number of recommendations to return.
#' @return A tibble: product, score, ranked highest first.
recommend_for_customer <- function(customer_id, interaction_matrix, item_similarity, n = 10) {
  customer_row <- as.character(customer_id)
  if (!customer_row %in% rownames(interaction_matrix)) {
    return(tibble(product = character(), score = numeric()))
  }

  purchased <- interaction_matrix[customer_row, ]
  purchased_items <- names(purchased)[purchased > 0]

  if (length(purchased_items) == 0) return(tibble(product = character(), score = numeric()))

  # Score every NOT-yet-purchased product by summing its similarity to
  # everything the customer HAS already bought -- a product similar to
  # several of the customer's past purchases scores higher than one
  # similar to only one.
  scores <- rowSums(item_similarity[, purchased_items, drop = FALSE])
  scores <- scores[!(names(scores) %in% purchased_items)]   # never recommend something already bought

  tibble(product = names(scores), score = scores) |>
    arrange(desc(score)) |>
    slice_head(n = n)
}

#' Evaluate the recommender with a leave-one-out style holdout: for
#' each customer with at least 2 purchases, hide ONE of their real
#' purchases, generate recommendations from the rest, and check
#' whether the hidden item appears in the top-N recommendations. This
#' directly measures whether the recommender can predict something the
#' customer genuinely did, not just whether it produces plausible-
#' looking output.
#'
#' @param customer_products Original (customer_id, description) pairs.
#' @param n Number of recommendations to check (precision/recall @ N).
#' @param max_customers_to_test Cap for runtime -- evaluating every
#'   customer can be slow on a full dataset, so a random sample is
#'   used by default.
#' @return A tibble: customer_id, hidden_item, hit (logical, was the
#'   hidden item in the top-N recommendations).
evaluate_leave_one_out <- function(customer_products, n = 10, max_customers_to_test = 300, seed = 42) {
  set.seed(seed)

  eligible_customers <- customer_products |>
    count(customer_id) |>
    filter(n >= 2) |>
    pull(customer_id)

  test_customers <- sample(eligible_customers, min(max_customers_to_test, length(eligible_customers)))

  purrr::map_dfr(test_customers, function(cid) {
    cust_items <- customer_products |> filter(customer_id == cid) |> pull(description)
    hidden_item <- sample(cust_items, 1)

    # Rebuild the interaction matrix WITHOUT the hidden item for this
    # customer, so the recommender genuinely never saw it -- this is
    # what makes the evaluation honest rather than circular.
    training_data <- customer_products |>
      filter(!(customer_id == cid & description == hidden_item))

    im <- build_interaction_matrix(training_data)
    sim <- compute_item_similarity(im)
    recs <- recommend_for_customer(cid, im, sim, n = n)

    tibble(customer_id = cid, hidden_item = hidden_item, hit = hidden_item %in% recs$product)
  })
}
