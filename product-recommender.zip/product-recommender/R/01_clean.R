library(readxl)
library(dplyr)
source("R/cleaning.R")

raw   <- read_excel("data/raw/online_retail_II.xlsx")
clean <- clean_orders(raw)

cat("Customer-product pairs:", nrow(clean), "\n")
cat("Unique customers:      ", n_distinct(clean$customer_id), "\n")
cat("Unique products:       ", n_distinct(clean$description), "\n")

saveRDS(clean, "data/clean/customer_product_clean.rds")
