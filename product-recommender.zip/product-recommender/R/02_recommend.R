library(dplyr)
library(readr)
source("R/recommender_functions.R")

clean <- readRDS("data/clean/customer_product_clean.rds")

interaction_matrix <- build_interaction_matrix(clean)
item_similarity    <- compute_item_similarity(interaction_matrix)

cat("Interaction matrix:", nrow(interaction_matrix), "customers x",
    ncol(interaction_matrix), "products\n")

# Example: recommendations for one real customer, for a quick sanity check.
example_customer <- rownames(interaction_matrix)[1]
example_recs <- recommend_for_customer(example_customer, interaction_matrix, item_similarity, n = 10)
cat("\nExample recommendations for customer", example_customer, ":\n")
print(example_recs)

# Full evaluation: leave-one-out precision/recall @ 10, across a sample
# of customers. This is the step that answers "does this actually work,"
# not just "does this run."
eval_results <- evaluate_leave_one_out(clean, n = 10, max_customers_to_test = 300)

precision_at_10 <- mean(eval_results$hit)   # with 1 held-out item per customer, precision@10 and recall@10 for that customer are the same hit/miss
cat("\nLeave-one-out evaluation (", nrow(eval_results), "customers tested):\n")
cat("Hit rate @ 10 (precision@10 ~= recall@10 here):", round(precision_at_10, 4), "\n")

# Baseline for comparison: if we just recommended the N most popular
# products to EVERYONE (ignoring personal history entirely), what hit
# rate would that get by chance? A good recommender should clearly beat
# this -- if it doesn't, the "personalization" isn't adding real value.
popularity_rank <- clean |>
  count(description, sort = TRUE) |>
  slice_head(n = 10) |>
  pull(description)

baseline_hits <- eval_results |>
  rowwise() |>
  mutate(hit_popularity = hidden_item %in% popularity_rank) |>
  ungroup()

cat("Popularity-baseline hit rate @ 10:", round(mean(baseline_hits$hit_popularity), 4), "\n")

saveRDS(interaction_matrix, "data/clean/interaction_matrix.rds")
saveRDS(item_similarity, "data/clean/item_similarity.rds")
saveRDS(eval_results, "data/clean/eval_results.rds")
saveRDS(baseline_hits, "data/clean/baseline_hits.rds")

write_csv(example_recs, "data/clean/example_recommendations.csv")
