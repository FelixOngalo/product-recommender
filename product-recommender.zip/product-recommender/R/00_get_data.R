# Data: reuse "Online Retail II" (same dataset used across several
# projects in this portfolio) -- transaction-level data, which we'll
# turn into a CUSTOMER x PRODUCT purchase matrix for collaborative
# filtering.
#   https://archive.ics.uci.edu/dataset/502/online+retail+ii
# Download the XLSX and place it at data/raw/online_retail_II.xlsx
# (reuse the file from earlier projects if you already have it).
#
# This project uses the same underlying data as market-basket-analysis
# and product-network-analysis, but for a different end goal: instead
# of mining rules or studying network structure, the point here is to
# build a working RECOMMENDER -- "customers like you also bought..." --
# and to evaluate how good its recommendations actually are.
message("Download Online Retail II to data/raw/online_retail_II.xlsx (reuse from earlier projects if you already have it)")
