library(dplyr)
library(janitor)
library(stringr)

clean_orders <- function(raw) {
  raw |>
    clean_names() |>
    rename(any_of(c(
      invoice_no  = "invoice",
      customer_id = "customer_id",
      description = "description"
    ))) |>
    mutate(
      description  = str_squish(str_to_upper(description)),
      is_cancelled = grepl("^C", as.character(invoice_no))
    ) |>
    filter(
      !is_cancelled,
      !is.na(customer_id),
      !is.na(description), description != "",
      quantity > 0
    ) |>
    distinct(customer_id, description)   # one row per (customer, product ever bought) -- implicit feedback, not ratings
}
