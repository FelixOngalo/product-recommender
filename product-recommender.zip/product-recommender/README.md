# Product Recommender (Item-Based Collaborative Filtering)

**Question:** *(fill in)* Can we recommend products to a customer based purely on co-purchase patterns across the customer base, and does that personalization actually beat recommending the same bestsellers to everyone?

**Key findings:** *(fill in after running the analysis; hit rate @ 10 for collaborative filtering vs. the popularity baseline)*

**Tools:** R, Matrix (sparse matrices), tidyverse, cosine similarity, leave-one-out evaluation, Quarto report

## Reproduce

1. Download the "Online Retail II" dataset (see `R/00_get_data.R`) and place it at `data/raw/online_retail_II.xlsx` — reuse the file from `market-basket-analysis` or `product-network-analysis` if you already have it, it's the same source data.
2. `install.packages(c("tidyverse", "readxl", "janitor", "Matrix", "scales"))`
3. Run in order:
   - `R/01_clean.R` builds (customer, product) purchase pairs
   - `R/02_recommend.R` builds the recommender, generates example recommendations, and runs the leave-one-out evaluation
   - Render `reports/report.qmd` for the written analysis

## Data

UCI Machine Learning Repository / Kaggle: "Online Retail II", real transactions from a UK-based online retailer, Dec 2009-Dec 2011. Only `customer_id` and `description` are used — each (customer, product) pair appears once, regardless of how many times that customer bought that product (this is **implicit feedback**: "bought at least once," not a rating or purchase count).

## Method in brief

**Item-based collaborative filtering:**
1. Build a sparse customer x product matrix of 1s (bought) and 0s (did not).
2. Compute **cosine similarity** between every pair of products, based on how much their "who bought this" customer sets overlap.
3. For a given customer, score every product they haven't bought by summing its similarity to everything they *have* bought, and recommend the highest-scoring ones.

**Evaluation:** leave-one-out — hide one real purchase per customer, rebuild recommendations from the rest, and check whether the recommender's top-10 includes the hidden item. Compared against a popularity baseline (same top-10 bestsellers recommended to every customer) to check whether personalization is actually adding value over the simplest possible alternative.

## Key concepts

| Concept | What it means here |
|---|---|
| **Collaborative filtering** | Recommending based only on purchase patterns — no product attributes used at all |
| **Item-based vs. user-based CF** | Item-based finds similar *products*; user-based finds similar *customers*. Item-based used here because the product catalog is smaller and more stable than the customer base |
| **Implicit feedback** | Binary "bought / didn't buy" signal, as opposed to explicit star ratings — the far more common real-world case |
| **Cosine similarity** | Measures overlap between two products' purchasing customer sets, normalized so popularity alone doesn't inflate similarity |
| **Cold-start problem** | New customers (no history) or new products (no purchases yet) have little or nothing for the recommender to work from |
| **Leave-one-out evaluation** | Hiding one real purchase per customer and checking whether the model would have predicted it, for an honest test rather than a plausibility check |
| **Popularity baseline** | The simplest possible recommender (same bestsellers for everyone) — the bar true personalization needs to clear |

## Project structure

```
R/00_get_data.R              links to the raw data (manual download)
R/cleaning.R                 cleaning function
R/01_clean.R                 run cleaning, save cleaned (customer, product) pairs
R/recommender_functions.R    interaction matrix, cosine similarity, recommend, leave-one-out eval
R/02_recommend.R             run the recommender + evaluation, save results
reports/report.qmd           written analysis and charts
```

## Limitations

- Implicit feedback can't distinguish "not interested" from "never saw it."
- Co-purchases are treated as equally important regardless of when they happened — no recency or seasonality weighting.
- Leave-one-out checks only whether the single hidden item is recovered, not the quality of the other 9 recommendations.
- Recommends only within a customer's established pattern — can create a "filter bubble" with no built-in novelty boost.
- *(add your own after running it on your own data)*
